import React from 'react'

export default function Homepage() {
  return (
    <div>
      <div>
      <h1>Welcome to the Home Page</h1>
      <p>This is a basic home page created using React.</p>
    </div>
    </div>
  )
}
