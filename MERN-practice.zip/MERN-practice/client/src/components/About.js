import React from 'react'
import './stylesheets/about.css'

export default function About() {
  return (
    <div className="container">
    <h1>About Gloria Jeans</h1>
    <p>Gloria Jeans is a renowned coffeehouse chain that was founded in 1979 in Chicago. With a mission to provide high-quality coffee and exceptional customer service, Gloria Jeans has grown to become a global brand with numerous locations worldwide.</p>
    
    <p>At Gloria Jeans, we are dedicated to sourcing the finest coffee beans from around the world. Our expert team of baristas skillfully crafts each cup of coffee to perfection, ensuring that our customers get to experience the rich flavors and aromas in every sip.</p>
    
    <p>But Gloria Jeans is more than just a coffeehouse. We strive to create a warm and inviting atmosphere where people can come together, connect, and enjoy moments of respite. Whether you're catching up with friends, having a business meeting, or simply seeking a quiet place to relax, Gloria Jeans welcomes you with open arms.</p>
    
    <p>Our commitment to sustainability is at the core of our operations. We work closely with coffee farmers and suppliers to ensure ethical sourcing practices, support local communities, and minimize our environmental footprint. By choosing Gloria Jeans, you are not only indulging in exceptional coffee but also contributing to a more sustainable future.</p>
    
    <p>Visit our locations page to find a Gloria Jeans near you and experience the unparalleled taste and ambiance that we have to offer. Join us on this coffee journey and discover why Gloria Jeans has become a beloved destination for coffee enthusiasts worldwide.</p>
  </div>
  )
}
