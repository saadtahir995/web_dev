import React from 'react';
import { useLocation,useNavigate } from 'react-router-dom'
const AuthPage = () => {
  const navigate=useNavigate();
    const location = useLocation();
    const userData = location?.state?.userData;
    const mystyle={
      position:'absolute',
      top: '1%',
      left: '93%',
    }
    const HandleLogout=async()=>{
      await fetch('http://localhost:8000/api/logout/del').then(localStorage.clear());
        navigate('/login');
     
    }

  return (
    <div>
      <h1>Welcome {userData.username}!<br/> Authenticated Page!</h1>
      <p>This is the content that only authenticated users can access.</p>
      <button className='btn btn-primary' style={mystyle} onClick={HandleLogout}>Logout</button>
    </div>
  );
};

export default AuthPage;
