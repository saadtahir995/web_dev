import express from 'express';
const app = express();
import cors from 'cors'
import routers from './Routes/UserSessionsroute.js';

app.use(
  cors({
    origin: 'http://localhost:3000',
    credentials: true,
    optionsSuccessStatus: 200
}));
app.use('/api/login',routers);
app.use('/api/sessionchk', routers);
app.use('/api/logout', routers);

const port = 8000;


app.listen(port,()=>{
    console.log(`listening on port: ${port}`);
});