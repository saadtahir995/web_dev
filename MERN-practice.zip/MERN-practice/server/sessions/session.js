import session from 'express-session';
import MySQLStoreModule from 'express-mysql-session';
 const MySQLStore= MySQLStoreModule(session);
 const sessionStore = new MySQLStore({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '',
    database: 'session_storage',
    clearExpired: true,
    checkExpirationInterval: 10000, // Cleanup expired sessions every 15 minutes
    //expiration:300000, // Session expiration time (in milliseconds), set to 5 minutes
  });

  const sessionmiddleware = session({
    secret: 'your-secret-key',
    resave: false,
    store: sessionStore,
    saveUninitialized: true,
    cookie: {
      maxAge: 300000, // Set the maxAge to 5 minutes (in milliseconds)
      httpOnly: true,
      path: '/',
    },
  });
  export default sessionmiddleware;