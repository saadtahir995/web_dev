import express from 'express';
import db from '../database.js';
const app =express();
import bodyParser from 'body-parser';
import session from '../sessions/session.js';
import jwt from 'jsonwebtoken';

app.use(session);
app.use(bodyParser.json());
app.use(express.urlencoded({
  extended: true
}));const SECRET_KEY='fuckoff';
app.post('/chk',async(req,res)=>{
    const mail= req.body.email;
    const pass= req.body.pwd;
    const [rows,fields]= await db.execute(`Select * from user_cred where user_pwd = "${pass}" and user_email = "${mail}"`)
    if(rows.length>0)
    {
      req.session.username=rows[0].user_name;
      const token = jwt.sign({username : req.session.username },SECRET_KEY);

      res.json({Isloggedin:true,
        username:  req.session.username,
        tokenn: token
      });
  
    }
    else
    console.log('not');
   
  });
  app.get('/chk',(req,res)=>{
  if(req.session.username)
  {
    res.json({Isloggedin:true,
      username:  req.session.username
    });
  }
  else{
    res.json({Isloggedin:false});
  }
  });
  app.get('/del',async(req,res)=>{
     req.session.destroy();
     res.json({message : 'logged out and Session Deleted'});
  })
  export default app;