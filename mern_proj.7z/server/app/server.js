import express from 'express';
const app = express();
import cors from 'cors'
import routers from '../Routes/UserSessionsroute.js';
import SignupRoute from '../Routes/seeder/signup.js';
import dataseeder from '../dataseeder/dbseeder.js';
import seeddata from '../Routes/seeddata.js';
import cartdataroute from '../Routes/cartdata.js';

app.use(
  cors({
    origin: 'http://localhost:3000',
    credentials: true,
    optionsSuccessStatus: 200
}));
await dataseeder();
app.use('/api/login',routers);
app.use('/api/sessionchk', routers);
app.use('/api/logout', routers);
app.use('/api',SignupRoute);
app.use('/apidata',seeddata);
app.use('/apicart',cartdataroute);

const port = 8000;

 
app.listen(port,()=>{
    console.log(`listening on port: ${port}`);
});