import db from '../database/database.js';
import products from './seeddata/data.js';
const seeddatabase=async() => {
    try {

        await db.query('DROP TABLE IF EXISTS products');
        await db.query('CREATE TABLE IF NOT EXISTS products (product_id SERIAL PRIMARY KEY,product_name VARCHAR(255) NOT NULL,product_price INTEGER NOT NULL,product_image TEXT NOT NULL,product_description TEXT NOT NULL,product_category VARCHAR(255) NOT NULL)');
         products.forEach(element => {
             db.execute(`INSERT INTO products (product_name,product_price,product_image,product_description,product_category) VALUES ("${element.name}","${element.price}","${element.image}","${element.description}","${element.category}")`);

            
         });
        console.log('Database seeded!');
    }
    catch (error) {
        console.log(error);
       // res.status(500).send('Error in seeding database!');
    }
};
export default seeddatabase;
