import db from '../database/database.js';


const Signupchk=async(req,res,next)=>{
const [rows,fields]= await db.execute(`Select * from user_cred where user_email = "${req.body.formData.Email}"`)
if(rows.length>0)
{
    res.json({IsSignedUp: false,
        message:'Email Already Exist'
    });
}
else{
    next();
}
}
export default Signupchk;