import React,{useState} from 'react'

const Signup=()=>{

    const[formData,setFormData]=useState({
      Name:'',
      Email:'',
      pwd:'',
      cpwd:''
    });
    const[message,setMessage]=useState('');
    const HandleSubmit=async(e)=>{
      e.preventDefault();
      const response =await fetch('http://localhost:8000/api/signup',{

        method:'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({formData}),
      })
      const data=await response.json();
        setMessage(data.message);
        if(data.IsSignedUp)
        {
          setTimeout(()=>{
            window.location.href='/login';
          },3000);
        }
      
    }
  return (
    
    <div className='container'>
        <h3>Sign-Up</h3>
        <form onSubmit={HandleSubmit}>
        <input type="text" name="name" id="name" placeholder='Enter Full Name' required onChange={(e)=>{
            setFormData({...formData,Name:e.target.value});
        }} /> <br />
        <input type="email" name="mail" id="mail" placeholder='Enter Your Email' required onChange={(e)=>{
            setFormData({...formData,Email:e.target.value});
        }} /> <br />
        <input type="password" name="pwd" id="pwd" placeholder='Enter Your Password' required onChange={(e)=>{
            setFormData({...formData,pwd:e.target.value});
        }} /> <br />
        <input type="password" name="cpwd" id="cpwd" placeholder='Confirm Your Password' required onChange={(e)=>{
            setFormData({...formData,cpwd:e.target.value});
        }} /> <br />
        <button type='Submit' className='btn btn-primary '>Sign-Up</button>
        <div id="display">{message}</div>
        </form>
        
        </div>
  )
}
export default Signup;
