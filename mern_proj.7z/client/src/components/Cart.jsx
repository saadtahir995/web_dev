import React,{useState,useEffect} from 'react'
import './stylesheets/cart.css'
export default function Cart() {
    const [Cartdata, setCartdata] = useState([]);
    const [IsLoading, setIsLoading] = useState(true);
    const [Total, setTotal] = useState(0);
    useEffect(() => {
      const data=sessionStorage.getItem('userid')
        const response=fetch(`http://localhost:8000/apicart/cartdata/getdata`,{
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },     
            body: JSON.stringify({udata:data})
        })
        .then(response => response.json())
        .then(data =>setCartdata(data))
        .catch(error => console.log(error));
        setTimeout(() => {
          setIsLoading(false);
        },1000)
    }, [])
    const total=()=>{
      let sum=0;
      Cartdata.map((item)=>{
        sum=sum+item.total_bill;
      })
      setTotal(sum);
    }
    useEffect(() => {
      total();
    },[Cartdata])
    


  return (
    <div>
      {IsLoading ? (<div className="spinner-border text-primary mybox" role="status">
          {" "}
          <span className="sr-only">Fetching Data....</span>
        </div> ):(<>
          <h1 className='mb-5'>Shopping Cart</h1>
      <div className="cart-item">
        <div className="item-name">Item Name</div>
        <div className="item-count">Item Count</div>
        <div className="item-price">Item Price</div>
      </div>
        {Cartdata.map((item) => (<>
            
      <div className="cart-item" key={item.item_id}>
        <div className="item-name" key={item.item_id+1}>{item.item_name}</div>
        <div className="item-count" key={item.item_id+3}>{item.item_count}</div>
        <div className="item-price" key={item.item_id+2}>{item.total_bill}</div>

      </div>
      
      </>
        ))}
        
        <div className="cart-total">
        Total Price: {Total}
      </div>
      </>)};
      
    </div>
  )
}
