#include<stdio.h>
int main()
{
int arr[20],size,tmp;
printf("Enter 20 numbers");
for (int i = 0; i < 20; i++)
{
    scanf("%d",&arr[i]);
    size++;
    if(arr[i]==-99)
    {
        i--;
        size=i;
       break;
    }
    size=i;
}
printf("Original Sequence : \n");
for (int i = 0; i < size; i++)
{
    printf(" %d",arr[i]);
}

for (int i = 0; i < size; i++)
{
    for (int j = i+1; j < size ; j++)
    {
        if(arr[i]>arr[j])
        {
          tmp=arr[j];
          arr[j]=arr[i];
          arr[i]=tmp;

        }
    }
    
}

printf("\n");
printf("Sorted Sequence : \n");
for (int i = 0; i < size; i++)
{
    printf(" %d",arr[i]);
}






}
