#include<stdio.h>
int main()
{
    int area,length,width=0;
    printf("Enter the Length and width of rectangle : \n");
    scanf("%d%d",&length,&width);
    area=length*width;
    printf("Area of Rectangle is %d",area);
    return 0;
}