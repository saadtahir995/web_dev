#include<stdio.h>
int main()
{
int suma,sumb,sumc,lengtha,lengthb,lengthc=0;
printf("Enter the length of 3 sides of triangle respectively : \n");
scanf("%d%d%d",&lengtha,&lengthb,&lengthc);
suma=lengtha+lengthb;
sumb=lengthb+lengthc;
sumc=lengtha+lengthc;
if(lengtha>sumb || lengthb>sumc || lengthc>suma)
{

printf("Not a triangle");


}
else
{
if(lengtha==lengthb && lengtha ==lengthc)
{
printf("Equilateral trainagle");
}
else if(lengtha==lengthb || lengtha==lengthc || lengthb==lengthc)
{

printf("Isosceles trainagle");


}
else
{
printf("Scalene trainagle");


}





}
return 0;

}

