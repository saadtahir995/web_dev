const products=[
{
name:"Colorpia Magenta",
price: 3150,
image:"https://scontent.fisb6-2.fna.fbcdn.net/v/t39.30808-6/306268418_496086515857220_6720920100927884614_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=e3f864&_nc_ohc=m8fP3_5FDqkAX99ywXm&_nc_zt=23&_nc_ht=scontent.fisb6-2.fna&oh=00_AfAAY2VhXktZMnUDEmRzkRaeCg5tZXG-jAZhlwpnJhTCNg&oe=64BF4DE2",
description:"Colorpia Magenta Ink: Vibrant and Versatile. Unleash Your Creativity with Intense Hue. Perfect for Illustrations, Watercolors, Calligraphy, and More.",
category:"Ink",
},
{
name:"Colorpia Cyan",
price: 3100,
image:"https://scontent.fisb6-2.fna.fbcdn.net/v/t39.30808-6/306268418_496086515857220_6720920100927884614_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=e3f864&_nc_ohc=m8fP3_5FDqkAX99ywXm&_nc_zt=23&_nc_ht=scontent.fisb6-2.fna&oh=00_AfAAY2VhXktZMnUDEmRzkRaeCg5tZXG-jAZhlwpnJhTCNg&oe=64BF4DE2",
description:"Colorpia Cyan Ink: A vibrant and refreshing shade of cyan, perfect for adding a touch of coolness and tranquility to your artistic creations. With Colorpia's quality and brilliance.",
category:"Ink",
},
{
name:"Colorpia Yellow",
price: 3200,
image:"https://scontent.fisb6-2.fna.fbcdn.net/v/t39.30808-6/306268418_496086515857220_6720920100927884614_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=e3f864&_nc_ohc=m8fP3_5FDqkAX99ywXm&_nc_zt=23&_nc_ht=scontent.fisb6-2.fna&oh=00_AfAAY2VhXktZMnUDEmRzkRaeCg5tZXG-jAZhlwpnJhTCNg&oe=64BF4DE2",
description:"Colorpia Cyan Ink: A vibrant and refreshing shade of cyan, perfect for adding a touch of coolness and tranquility to your artistic creations.",
category:"Ink",
},
{
name:"Colorpia Black",
price: 3300,
image:"https://scontent.fisb6-2.fna.fbcdn.net/v/t39.30808-6/306268418_496086515857220_6720920100927884614_n.jpg?_nc_cat=104&ccb=1-7&_nc_sid=e3f864&_nc_ohc=m8fP3_5FDqkAX99ywXm&_nc_zt=23&_nc_ht=scontent.fisb6-2.fna&oh=00_AfAAY2VhXktZMnUDEmRzkRaeCg5tZXG-jAZhlwpnJhTCNg&oe=64BF4DE2",
description:"Colorpia Black Ink: Timeless elegance, rich and velvety. Perfect for adding depth and sophistication to your art.",
category:"Ink",
},
{
name:"Pastel-C Yellow",
price: 2850,
image: "https://image.ec21.com/image/crownink/OF0009382782_1/Sell_Sheetfed_Offset_Printing_Inks.jpg",
description:"Pastel-C Yellow Ink: A vibrant and refreshing shade of cyan, perfect for adding a touch of coolness and tranquility to your artistic creations.",
category:"Ink",
},
{
name:"Pastel-C Magenta",
price: 2900,
image:"https://image.ec21.com/image/crownink/OF0018695812_1/Sell_Sheetfed_Offset_Printing_Inks.jpg",
description:"Pastel-C Magenta Ink: Vibrant and Versatile. Unleash Your Creativity with Intense Hue. Perfect for Illustrations, Watercolors, Calligraphy, and More.",
category:"Ink",
},
{
name:"Pastel-C Cyan",
price: 2900,
image:"http://www.myprintpack.com/uploadfile/offer/334/2015/10/26/1445824799.jpg_600X600.jpg",
description:"Pastel-C Cyan Ink: A vibrant and refreshing shade of cyan, perfect for adding a touch of coolness and tranquility to your artistic creations. With Colorpia's quality and brilliance.",
category:"Ink",
},
{
name:"Pastel-C Black",
price: 2850,
image:"http://www.myprintpack.com/uploadfile/offer/334/2015/10/26/1445825531.jpg_600X600.jpg",
description:"Pastel-C Black Ink: Timeless elegance, rich and velvety. Perfect for adding depth and sophistication to your art.",
category:"Ink",
},
]
export default products;