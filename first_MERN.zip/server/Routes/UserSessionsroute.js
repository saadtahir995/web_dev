import express from "express";
import config from "../config/appconfig.js";
import middleware from "../Middleware/loginvalid.js";
const app = express();

app.use(config);
app.post("/chk", middleware, (req, res) => {
 const userId=req.userid;
 const userName=req.username;
 const token=req.token;
 const logged=req.isLoggedin;
 const msg=req.message;
  res.json({
    Isloggedin: logged,
    username: userName,
    userid: userId,
    tokenn: token,
    message: msg,
  });
});
app.get("/del", async (req, res) => {
  req.session.destroy();
  res.clearCookie("mycookie", {
    path: "/userHome",
    domain: "http://localhost:3000",
  });
  res.json({ message: "logged out and Session Deleted" });
});
export default app;
