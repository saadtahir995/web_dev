import express from 'express';
const app = express();
import db from '../database/database.js';
import config from '../config/appconfig.js';

app.use(config);
app.get('/seeddata', async (req, res) => {
    try {
        
        const [rows,field] = await db.execute('SELECT * FROM products');
        res.json(rows);
    } catch (error) {
        console.log(error);
    }
    });
    export default app;

