import express from 'express'
import db from '../../database/database.js'
import config from '../../config/appconfig.js'
import signUpMiddleware from '../../Middleware/SignupValidation.js'
const app = express();
const router=express.Router();
router.use(config);
router.post('/signup',signUpMiddleware, async(req,res)=>{
    const name=req.body.formData.Name;
    const email=req.body.formData.Email;
    const pwd=req.body.formData.pwd;
    const [rows,fields]= await db.execute(`insert into user_cred(user_name,user_email,user_pwd) values("${name}","${email}","${pwd}")`);
    res.json({IsSignedUp:true,
        message:'User Signed Up Successfully'
    });
})
export default router;