import express from 'express';
import db from '../database/database.js';
import config from '../config/appconfig.js';
import {cartgetvalid,cartaddvalid} from '../Middleware/cartvalid.js';
const app=express();
app.use(config);

app.post('/cartdata/getdata',cartgetvalid,async (req, res) => {
    try {
        const userid=req?.body?.obj?.userid;
        
        const [rows, fields] = await db.execute(`SELECT * FROM cartitems_data where customer_id=${userid}`);
        //if(rows.length>0)
        
        res.json(rows);
        
        
    } catch (error) {
        console.log(error);
    }
});

app.post('/cart/add', async (req, res) => {
    try {

        const count= req.body.count;
        const product_name= req.body.product_name;
        var price= req.body.price;
        const userid=req.body.userid;
        price=price*count;
        const [rows, fields] = await db.execute(`INSERT into cartitems_data (customer_id,item_name,item_count,total_bill) values("${userid}","${product_name}","${count}","${price}")`);
        res.json({message:'Item added to cart'});
    } catch (error) {
        console.log(error);
    }
});
export default app;
