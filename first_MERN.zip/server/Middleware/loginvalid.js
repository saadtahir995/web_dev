import express from "express";
import db from "../database/database.js";
import config from "../config/appconfig.js";
import jwt from "jsonwebtoken";

const app = express();
app.use(config);
const SECRET_KEY = "fuckoff";

const loginMiddleware = async (req, res, next) => {
  const mail = req.body.email;
  const pass = req.body.pwd;
  var isLoggedin = false;
  try {
    const [rows, fields] = await db.execute(
      `Select * from user_cred where user_pwd = "${pass}" and user_email = "${mail}"`
    );
    if (rows.length > 0) {
      isLoggedin = true;
      const token = jwt.sign({ username: req.session.username }, SECRET_KEY);
      req.session.username = rows[0].user_name;
      const data = { key: req.session.username };
      res.cookie("mycookie", data, { maxAge: 1000000 });
      const userid = rows[0].user_id;
      const username = rows[0].user_name;
      const message = "User Logged in Successfully. Redirecting to Main Page";
      req.userid = userid;
      req.username = username;
      req.message = message;
      req.isLoggedin = isLoggedin;
      req.token = token;
    } else {
      isLoggedin = false;
      req.userid = null;
      req.username = null;
      req.message = "Invalid Credentials";
      req.isLoggedin = isLoggedin;
      req.token = null;
    }
    next();
  } catch (error) {
    console.log(error);
  }
};

export default loginMiddleware;
