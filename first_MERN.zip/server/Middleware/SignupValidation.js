import db from '../database/database.js';


const Signupchk=async(req,res,next)=>{
    try{
    const Email=req.body?.formData?.Email;
    const pwd=req.body?.formData?.pwd;
    if(!Email||!pwd)
    {
        return res.status(400).json({Message:'Please Enter All Fields'});
    }


const [rows,fields]= await db.execute(`Select * from user_cred where user_email = "${req.body.formData.Email}"`)
if(rows.length>0)
{
    res.json({IsSignedUp: false,
        message:'Email Already Exist'
    });
}
else{
    next();
}
    }
    catch(err)
{
    console.log(err)   ;
} 
}
export default Signupchk;