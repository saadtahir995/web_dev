import express from 'express';
import config from '../config/appconfig.js'
const app=express();
app.use(config);
const cartgetvalid=(req,res,next)=>{
    try {
        const userid=req.body?.obj?.userid;
        if(!userid)
        {
            return res.status(400).json({Message:'Please Enter All Fields'});
        }
        next();
    } catch (error) {
        console.log(error);
    }
}

const cartaddvalid=(req,res,next)=>{
    try {
        const count= req?.body?.count;
        const product_name= req?.body?.product_name;
        var price= req?.body?.price;
        const userid=req?.body?.userid;
        if(!count || !product_name || !price || !userid)
        {
            return res.status(400).json({Message:'Please Enter All Fields'});
        }
        next();
    } catch (error) {
        console.log(error);
    }
}
const handleEmptyRequestBody = (req, res, next) => {
    if (Object.keys(req.body).length === 0 && req.body.constructor === Object) {
      // Empty request body, just pass it along
            return res.status(400).json({Message:'Please Enter All Fields'});
    } else {
      next();
    }
  };
export{cartgetvalid,cartaddvalid,handleEmptyRequestBody};
