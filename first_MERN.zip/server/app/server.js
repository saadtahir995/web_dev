import express from 'express';
const app = express();
import cors from 'cors'
import routers from '../Routes/UserSessionsroute.js';
import SignupRoute from '../Routes/seeder/signup.js';
import dataseeder from '../dataseeder/dbseeder.js';
import seeddata from '../Routes/seeddata.js';
import cartdataroute from '../Routes/cartdata.js';
import config from '../config/appconfig.js';
import { handleEmptyRequestBody } from '../Middleware/cartvalid.js';
app.use(config);
app.use(
  cors({
    origin: 'http://localhost:3000',
    credentials: true,
    optionsSuccessStatus: 200
}));
await dataseeder();
app.post('*', handleEmptyRequestBody);
app.use('/api/login',routers);
app.use('/api/sessionchk', routers);
app.use('/api/logout', routers);
app.use('/api',SignupRoute);
app.use('/apidata',seeddata);
app.use('/apicart',cartdataroute);

const port = 8000;

 
app.listen(port,()=>{
    console.log(`listening on port: ${port}`);
});