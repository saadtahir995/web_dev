import session from 'express-session';


  const sessionmiddleware = (session({
    secret: 'your-secret-key',
    resave: true,
    saveUninitialized: true,
    cookie: {
      maxAge: 300000, // Session duration in milliseconds
      sameSite: 'none',
      secure: true
    },
  }));
  export default sessionmiddleware;