import React,{useState,useEffect} from 'react'
import { useNavigate , Link } from 'react-router-dom';
export default function Loginform() {
const navigate=useNavigate();
const [email, setemail] = useState('');
const [pwd, setpwd] = useState('');
const [msg, setmsg] = useState('');
useEffect(() => {
  
 if(localStorage.getItem('mytoken')&&document.cookie.includes('mycookie'))
 {

  const userData={
    username: localStorage.getItem('myusername'),
  }
   navigate('/userHome',{ state: {userData} });
 }
},[]);

 const handleSubmit=(e)=>{
  e.preventDefault();
   fetch('http://localhost:8000/api/login/chk',{
    method:'POST',
    credentials: 'include',

    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({email,pwd}),
   })
   .then((response) => response.json())
      .then((userData) => {
        if(userData?.Isloggedin)
        {
          sessionStorage.setItem('username',userData.username);
          sessionStorage.setItem('userid',userData.userid);

        localStorage.setItem('mytoken',userData.tokenn );
        localStorage.setItem('myusername',userData.username );
            setTimeout(() => {
              navigate('/userHome',{ state: {userData} });              
            },1000);
          
        }
        
          setmsg(userData.message)
      
        
      })
      .catch((error) => {
        console.error(error);
      });
 };
  return (
    <>

   <form onSubmit={handleSubmit}>
  <div className="mb-3">
    <label htmlFor="exampleInputEmail1" className="form-label">Email address</label>
    <input type="email" className="form-control" onChange={(e)=>{setemail(e.target.value)}} id="exampleInputEmail1" aria-describedby="emailHelp"/>
    <div id="emailHelp" className="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div className="mb-3">
    <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
    <input type="password" className="form-control" onChange={(e)=>{setpwd(e.target.value)}} id="exampleInputPassword1"/>
  </div>
  <button type='Submit' className="btn btn-primary">Submit</button>  <Link to= "/SignUp"><button className="btn btn-primary">SignUp</button></Link>
</form>
<div className="container">{msg}</div>
</>
  )
}
