import React, { useEffect, useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { BsFillCartCheckFill } from "react-icons/bs";
import { AiOutlinePlusCircle, AiOutlineMinusCircle } from "react-icons/ai";
import "./stylesheets/auth.css";

const AuthPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const userData = location?.state?.userData;
  const [Data, setData] = useState([]);
  const [Loading, setLoading] = useState(true);
  const [count, setcount] = useState([]);
  const [message, setmessage] = useState("");
  
  const mystyle = {
    position: "absolute",
    top: "0.5%",
    left: "93%",
  };
  const HandleLogout = async (e) => {
    e.preventDefault();
    await fetch("http://localhost:8000/api/logout/del", {
      credentials: "include",
    });
    localStorage.clear();
    sessionStorage.clear();
    navigate("/login");
  };
  useEffect(() => {
    if (
      sessionStorage.getItem("username") === null ||
      !document.cookie.includes("mycookie")
    ) {
      navigate("/login");
    }

    fetchdata();
  }, []);
  const fetchdata = async () => {
    try {
      const response = await fetch("http://localhost:8000/apidata/seeddata");
      const data = await response.json();
      setData(data);
      setcount(Array(data.length).fill(0));
      setTimeout(() => {
        setLoading(false);
      }, 1000);
    } catch (error) {
      setmessage(error);
    }
  };
  const HandleAdd = (index) => (e) => {
    e.preventDefault();
    setcount((prevcount) => {
      const updatedCounts = [...prevcount];
      updatedCounts[index] += 1;
      return updatedCounts;
    });
  };
  const HandleSub = (index) => (e) => {
    e.preventDefault();
    if (count[index] > 0) {
      setcount((prevcount) => {
        const updatedCounts = [...prevcount];
        updatedCounts[index] -= 1;
        return updatedCounts;
      });
    }
  };
  const HandleCartSubmit = (p_name, p_countt, p_price) => {
    //e.preventDefault();
    if (p_countt > 0) {
      fetch("http://localhost:8000/apicart/cart/add", {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          count: p_countt,
          product_name: p_name,
          price: p_price,
          userid: sessionStorage.getItem("userid"),
        }),
      })
        .then((res) => res.json())
        .then((data) => {
          setmessage(data.message);
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      setmessage("Please select atleast one item");
    }
  };

  return (
    <div>
      {Loading ? (
        <div className="spinner-border text-primary mybox" role="status">
          {" "}
          <span className="sr-only">Loading...</span>
        </div>
      ) : (
        <>
          <h1 className="mt-5">
            Welcome {userData?.username}!<br /> Authenticated Page!
          </h1>
          <p>This is the content that only authenticated users can access.</p>
          <button
            className="btn btn-primary"
            style={mystyle}
            onClick={HandleLogout}
          >
            Logout
          </button>
          <Link to="/userHome/cart">
            {" "}
            <BsFillCartCheckFill
              style={{
                fontSize: "2rem",
                position: "absolute",
                top: "0.5%",
                left: "87%",
              }}
            />
          </Link>

          <div className="row container">
            <p className="mydiv">Colorpia Ink</p>
            {Data.map((item, index) => {
              return (
                <>
                <div
                  className="col mt-4 justify-content-centre shadow-lg ml-3"
                  key={item.product_id}
                >
                  <img
                    className="mt-3"
                    src={item.product_image}
                    alt="cannot be rendered"
                    height={200}
                    width={320}
                  />
                  <h3 className="text-centre">{item.product_name}</h3>
                  <p className="text-centre">{item.product_description}</p>
                  <p className="mytxt font-weight-bold">
                    {item.product_price} Rs
                  </p>
                  <p className="mytxt font-weight-bold">
                    Quantity: {count[index]}
                  </p>
                  <button onClick={HandleAdd(index)}>
                    <AiOutlinePlusCircle style={{ fontSize: "2rem" }} />
                  </button>{" "}
                  <button
                    className="btn btn-primary"
                    onClick={() =>
                      HandleCartSubmit(
                        item.product_name,
                        count[index],
                        item.product_price
                      )
                    }
                  >
                    {" "}
                    Add to Cart
                  </button>{" "}
                  <button onClick={HandleSub(index)}>
                    <AiOutlineMinusCircle style={{ fontSize: "2rem" }} />
                  </button>
                </div>
                {index===3 &&<p className="mydiv mt-5">Pastel-C Ink</p>}
                </>
                
              );
            })}

            <div className="mytxt">{message}</div>
          </div>
        </>
      )}
      ;
    </div>
  );
};

export default AuthPage;
