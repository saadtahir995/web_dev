import React, { useReducer } from "react";

export default function Reducertest() {
  const reducer = (state, action) => {
    switch (action.type) {
      case "LOGIN":
        return { ...state, isLoggedin: true,isLoading: false,error: false };
      case "LOADING":
        return { ...state, isLoading: true };
      case "ERROR":
        return { ...state, error: true,isLoading: false,isLoggedin: false };
      case "UPDATED_FIELD":
        if (action.field === "email") {
          return {
            ...state,
            [action.field]: action.value,
            email: action.value,
          };
        } else {
          return {
            ...state,
            [action.field]: action.value,
            password: action.value,
          };
        }
      default:
        return state;
    }
  };

  const initialState = {
    isLoggedin: false,
    isLoading: false,
    error: false,
    email: "",
    password: "",
  };

  const [state, dispatch] = useReducer(reducer, initialState);
  const HandleSubmit = (e) => {
    e.preventDefault();
    dispatch({ type: "LOADING" });
    if(state.email === "saad123@test.com" && state.password === "123456"){
      setTimeout(() => {
      dispatch({ type: "LOGIN" });
      }, 2000);
    }else{
      setTimeout(() => {
      dispatch({ type: "ERROR" });
      }, 2000);
    }

  };

  return (
    <div>
      <form onSubmit={HandleSubmit} className="container">
        {state.error? <div className="alert alert-danger" role="alert"> Error </div> : null}
        <div className="mb-3">
          <label htmlFor="exampleInputEmail1" className="form-label">
            Email address
          </label>
          <input
            type="email"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            name="email"
            value={state.email}
            onChange={(e) => {
              dispatch({
                type: "UPDATED_FIELD",
                field: e.target.name,
                value: e.target.value,
              });
            }}
          ></input>
          <div id="emailHelp" className="form-text">
            We'll never share your email with anyone else.
          </div>
        </div>
        <div className="mb-3">
          <label htmlFor="exampleInputPassword1" className="form-label">
            Password
          </label>
          <input
            type="password"
            className="form-control"
            id="exampleInputPassword1"
            name="password"
            value={state.password}
            onChange={(e) => {
              dispatch({
                type: "UPDATED_FIELD",
                field: e.target.name,
                value: e.target.value,
              });
            }}
          ></input>
        </div>
        <div className="mb-3 form-check">
          <input
            type="checkbox"
            className="form-check-input"
            id="exampleCheck1"
          ></input>
          <label className="form-check-label" htmlFor="exampleCheck1">
            Check me out
          </label>
        </div>
        <button type="Submit" className="btn btn-primary">
          Submit
        </button>
        {state.isLoading ? ( <div className="spinner-border text-primary" role="status"> <span className="visually-hidden">Checking Credentials...</span> </div> ) : null}
         {state.isLoggedin ? ( <div className="alert alert-success" role="alert"> Logged in Successfully </div> ) : null}
      </form>
    </div>
  );
}
