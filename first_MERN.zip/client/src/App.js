import "./App.css";
import Navbar from "./components/Navbar";
import { Route, Routes,useLocation } from "react-router-dom";
import Homepage from "./components/Homepage";
import Loginform from "./components/Loginform";
import About from "./components/About";
import AuthPage from "./components/Authpage";
import Signup from "./components/Signup";
import Cart from "./components/Cart";
import Reducertest from "./test/Reducertest.jsx";

function App() {
const location = useLocation();
const route=location.pathname;
const isAuthpage=route==="/userHome" || route==="/userHome/cart";

  return (
    <>
    {isAuthpage?null:<Navbar />}       
        <Routes>
          <Route path="/" element={<Homepage />} />
          <Route path="/login" element={<Loginform />} />
          <Route path="/userHome" element={<AuthPage />} />
          <Route path="/userHome/cart" element={<Cart/>} />
          <Route path="/About" element={<About />} />
          <Route path="/Signup" element={<Signup />} />
          <Route path="/test" element={<Reducertest />} />
        </Routes>
        
    </>
  );
}

export default App;
