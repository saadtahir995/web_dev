#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>
#include<pthread.h>
#include<sys/wait.h>

sem_t Na_sem;
sem_t Cl_sem;
sem_t lock;
int Na_count=0;
int CL_count=0;

void* Na(void*arg)
{
    sem_wait(&lock);

       Na_count++;
       printf("Na atom is Crearted\n");
       if(Na_count>=1 && CL_count>=1)
       {
        printf("Salt is Crearted\n");
        Na_count--;
        CL_count--;
        sem_post(&Na_sem);
        sem_post(&Cl_sem);
       }
       sem_post(&lock);


}
void* CL(void*arg)
{
    sem_wait(&lock);

       CL_count++;
       printf("Cl atom is created\n");
       if(Na_count>=1 && CL_count>=1)
       {
        printf("Salt is Crearted\n");
        Na_count--;
        CL_count--;
        sem_post(&Na_sem);
        sem_post(&Cl_sem);
       }
       sem_post(&lock);


}
int main(int argc , char*argv[])
{
    sem_init(&Na_sem, 0, 0);
    sem_init(&Cl_sem, 0, 0);
    sem_init(&lock,0,1);
    pthread_t thread1, thread2;
    pthread_create(&thread1,NULL,Na,NULL);
    pthread_create(&thread2,NULL,CL,NULL);

    pthread_join(thread1,NULL);
    pthread_join(thread2,NULL);
}