#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>
#include<pthread.h>
#include<sys/wait.h>

sem_t std_sem;
sem_t teacher_sem;
sem_t lock;
int t_count=0;
int std_count=0;
void* std(void*arg)
{
    while(1)
    {
        sem_wait(&std_sem);
        sem_wait(&lock);
        //std_count++;
        printf("std Entered the Room\n");
        printf("std is being vaccinated\n");
        
        //sem_wait(&lock);
        //std_count--;
        
        sem_post(&lock);
        sem_post(&std_sem);
        printf("std left the room\n");
    }
    pthread_exit(NULL);
}
void* Teacher(void*arg)
{
    while(1)
    {
        sem_wait(&teacher_sem);
        sem_wait(&lock);
        //teacher_count++;
        printf("Teacher Entered the Room\n");
        printf("Teacher is being Vaccinated\n");
        
        //sem_wait(&lock);
        //teacher_count--;
        
        sem_post(&lock);
        sem_post(&teacher_sem);
        printf("teacher left the room\n");
    }
    pthread_exit(NULL);
}
int main(int argc , char*argv[])
{
    sem_init(&std_sem, 0, 3);
    sem_init(&teacher_sem, 0, 3);
    sem_init(&lock,0,1);
    pthread_t thread1, thread2;
    pthread_create(&thread1,NULL,std,NULL);
    pthread_create(&thread2,NULL,Teacher,NULL);

    pthread_join(thread1,NULL);
    pthread_join(thread2,NULL);



}