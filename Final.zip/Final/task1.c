#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int M, N; // Number of rows and columns
int** matrix1; // Input matrix 1
int** matrix2; // Input matrix 2
int** result; // Resultant matrix

void* matrixSum(void* arg) {
    int row = *(int*)arg;
    for (int col = 0; col < N; col++) {
        result[row][col] = matrix1[row][col] + matrix2[row][col];
    }
    pthread_exit(NULL);
}

void printMatrix(int** matrix) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printf("Usage: %s <M> <N>\n", argv[0]);
        return 1;
    }

    M = atoi(argv[1]);
    N = atoi(argv[2]);
    int threadarg[M];

    matrix1 = (int**)malloc(M * sizeof(int*));
    matrix2 = (int**)malloc(M * sizeof(int*));
    result = (int**)malloc(M * sizeof(int*));

    for (int i = 0; i < M; i++) {
        matrix1[i] = (int*)malloc(N * sizeof(int));
        matrix2[i] = (int*)malloc(N * sizeof(int));
        result[i] = (int*)malloc(N * sizeof(int));
    }

    srand(time(NULL));

    // Initialize input matrices with random values
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            matrix1[i][j] = rand() % 10;
            matrix2[i][j] = rand() % 10;
        }
    }

    pthread_t threads[M];

    // Create M worker threads
    for (int i = 0; i < M; i++) {
        threadarg[i]=i;
        pthread_create(&threads[i], NULL, matrixSum, &threadarg[i]);
    }

    // Wait for all threads to complete
    for (int i = 0; i < M; i++) {
        pthread_join(threads[i], NULL);
    }

    // Display the input matrices and the resultant matrix
    printf("Matrix 1:\n");
    printMatrix(matrix1);

    printf("\nMatrix 2:\n");
    printMatrix(matrix2);

    printf("\nResultant Matrix:\n");
    printMatrix(result);

    // Free allocated memory
    for (int i = 0; i < M; i++) {
        free(matrix1[i]);
        free(matrix2[i]);
        free(result[i]);
    }

    free(matrix1);
    free(matrix2);
    free(result);

  return 0;
}