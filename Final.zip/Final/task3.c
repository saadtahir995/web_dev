#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

long long int factorial = 1;  // Global variable to store the final factorial value
pthread_mutex_t mutex;        // Mutex to protect the factorial variable
int N ,M;
void* calculateFactorial(void* arg) {
    int threadId = *(int*)arg;
    long long int partialFactorial = 1;

    for (int i = threadId; i <= N; i += M) {
        partialFactorial *= i;
        printf("Thread %d: Partial factorial = %lld\n", threadId, partialFactorial);
    }

    pthread_mutex_lock(&mutex);
    factorial *= partialFactorial;
    pthread_mutex_unlock(&mutex);

    pthread_exit(NULL);
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        printf("Usage: %s <N> <M>\n", argv[0]);
        return 1;
    }

     N = atoi(argv[1]);
     M = atoi(argv[2]);

    if (N < M) {
        printf("Error: N must be greater than or equal to M.\n");
        return 1;
    }

    pthread_t threads[M];
    int threadIds[M];

    pthread_mutex_init(&mutex, NULL);

    // Create M threads
    for (int i = 0; i < M; i++) {
        threadIds[i] = i + 1;
        pthread_create(&threads[i], NULL, calculateFactorial, &threadIds[i]);
    }

    // Wait for all threads to complete
    for (int i = 0; i < M; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&mutex);

    printf("Final factorial: %lld\n", factorial);

   return 0;
}