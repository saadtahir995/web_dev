#include<stdio.h>
#include<stdlib.h>
#include<semaphore.h>
#include<pthread.h>
#include<sys/wait.h>

sem_t women_sem;
sem_t man_sem;
sem_t lock;
int man_count=0;
int women_count=0;
void* Man(void*arg)
{
    while(1)
    {
        sem_wait(&man_sem);
        sem_wait(&lock);
        man_count++;
        printf("Man Entered the Room\n");
        printf("Man is praying\n");
        
        //sem_wait(&lock);
        //man_count--;
        
        sem_post(&lock);
        sem_post(&man_sem);
        printf("man left the room\n");
    }
    pthread_exit(NULL);
}
void* Women(void*arg)
{
    while(1)
    {
        sem_wait(&women_sem);
        sem_wait(&lock);
        women_count++;
        printf("Woman Entered the Room\n");
        printf("Woman is praying\n");
        
        //sem_wait(&lock);
        //women_count--;
        
        sem_post(&lock);
        sem_post(&women_sem);
        printf("women left the room\n");
    }
    pthread_exit(NULL);
}
int main(int argc , char*argv[])
{
    sem_init(&man_sem, 0, 1);
    sem_init(&women_sem, 0, 1);
    sem_init(&lock,0,1);
    pthread_t thread1, thread2;
    pthread_create(&thread1,NULL,Man,NULL);
    pthread_create(&thread2,NULL,Women,NULL);

    pthread_join(thread1,NULL);
    pthread_join(thread2,NULL);



}